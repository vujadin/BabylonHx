# Fugo Spritesheet Example

A simple example of how to use the haxe spritesheet library based.  The example only cover the usage of Bitmap Spritesheet with OpenFL.

* Original NME spritesheet example [link](http://github.com/fugogugo/NMEspritesheetExample)
* Original Fugocode tutorial [link](http://fugocode.blogspot.com/2013/04/animated-sprite-using-bitmap.html)
* Artwork from opengameart.org [link](http://opengameart.org/content/kit-the-firefox-mascot)