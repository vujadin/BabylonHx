#!/bin/sh
openfl test neko
