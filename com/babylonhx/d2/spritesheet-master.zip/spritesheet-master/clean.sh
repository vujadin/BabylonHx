rm -rf Export/
rm -rf build/
rm -rf report/
rm -f test/TestMain.hx
rm -f test/TestSuite.hx
rm -f test/ExampleTest.hx
