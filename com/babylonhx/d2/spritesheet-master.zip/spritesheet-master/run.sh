#!/bin/sh
openfl test neko
openfl test cpp
haxelib run munit test
